﻿namespace E_Space_Solution
{
    partial class Pilot
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label15 = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.DOD = new System.Windows.Forms.Label();
            this.txtDeMiddlename = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtDeFirstname = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtDependentID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.cbDob = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.cbSpacehoures = new System.Windows.Forms.NumericUpDown();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.txtRank = new System.Windows.Forms.TextBox();
            this.txtQlification = new System.Windows.Forms.TextBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.cbDob.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cbSpacehoures)).BeginInit();
            this.SuspendLayout();
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(316, 21);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(253, 19);
            this.label15.TabIndex = 2;
            this.label15.Text = "Add Asstronomer\'s Data (PILOT)";
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(656, 255);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(98, 44);
            this.btnDelete.TabIndex = 30;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(656, 201);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(98, 41);
            this.btnSearch.TabIndex = 29;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(656, 148);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(98, 40);
            this.btnUpdate.TabIndex = 28;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(656, 97);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(98, 39);
            this.btnAdd.TabIndex = 27;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(28, 229);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 16);
            this.label10.TabIndex = 18;
            this.label10.Text = "Qulification";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(30, 283);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(48, 16);
            this.label11.TabIndex = 16;
            this.label11.Text = "Rank : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Asstronomer\'s Data";
            // 
            // DOD
            // 
            this.DOD.AutoSize = true;
            this.DOD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DOD.Location = new System.Drawing.Point(317, 77);
            this.DOD.Name = "DOD";
            this.DOD.Size = new System.Drawing.Size(36, 16);
            this.DOD.TabIndex = 12;
            this.DOD.Text = "DOB";
            // 
            // txtDeMiddlename
            // 
            this.txtDeMiddlename.Location = new System.Drawing.Point(128, 176);
            this.txtDeMiddlename.Multiline = true;
            this.txtDeMiddlename.Name = "txtDeMiddlename";
            this.txtDeMiddlename.Size = new System.Drawing.Size(135, 28);
            this.txtDeMiddlename.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(25, 185);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Last Name :";
            // 
            // txtDeFirstname
            // 
            this.txtDeFirstname.Location = new System.Drawing.Point(128, 118);
            this.txtDeFirstname.Multiline = true;
            this.txtDeFirstname.Name = "txtDeFirstname";
            this.txtDeFirstname.Size = new System.Drawing.Size(135, 28);
            this.txtDeFirstname.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(25, 127);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "First Name :";
            // 
            // txtDependentID
            // 
            this.txtDependentID.Location = new System.Drawing.Point(128, 68);
            this.txtDependentID.Multiline = true;
            this.txtDependentID.Name = "txtDependentID";
            this.txtDependentID.Size = new System.Drawing.Size(135, 28);
            this.txtDependentID.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Astronomer ID :";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(13, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(858, 290);
            this.panel1.TabIndex = 5;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(9, 53);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(837, 218);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // cbDob
            // 
            this.cbDob.Controls.Add(this.btnClear);
            this.cbDob.Controls.Add(this.label4);
            this.cbDob.Controls.Add(this.cbSpacehoures);
            this.cbDob.Controls.Add(this.dateTimePicker1);
            this.cbDob.Controls.Add(this.txtRank);
            this.cbDob.Controls.Add(this.txtQlification);
            this.cbDob.Controls.Add(this.label15);
            this.cbDob.Controls.Add(this.btnDelete);
            this.cbDob.Controls.Add(this.btnSearch);
            this.cbDob.Controls.Add(this.btnUpdate);
            this.cbDob.Controls.Add(this.btnAdd);
            this.cbDob.Controls.Add(this.label10);
            this.cbDob.Controls.Add(this.label11);
            this.cbDob.Controls.Add(this.DOD);
            this.cbDob.Controls.Add(this.txtDeMiddlename);
            this.cbDob.Controls.Add(this.label5);
            this.cbDob.Controls.Add(this.txtDeFirstname);
            this.cbDob.Controls.Add(this.label3);
            this.cbDob.Controls.Add(this.txtDependentID);
            this.cbDob.Controls.Add(this.label2);
            this.cbDob.Location = new System.Drawing.Point(13, 308);
            this.cbDob.Name = "cbDob";
            this.cbDob.Size = new System.Drawing.Size(858, 392);
            this.cbDob.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(25, 339);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 16);
            this.label4.TabIndex = 39;
            this.label4.Text = "Space Houser : ";
            // 
            // cbSpacehoures
            // 
            this.cbSpacehoures.Location = new System.Drawing.Point(128, 339);
            this.cbSpacehoures.Name = "cbSpacehoures";
            this.cbSpacehoures.Size = new System.Drawing.Size(137, 20);
            this.cbSpacehoures.TabIndex = 38;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(359, 73);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(155, 20);
            this.dateTimePicker1.TabIndex = 37;
            // 
            // txtRank
            // 
            this.txtRank.Location = new System.Drawing.Point(126, 282);
            this.txtRank.Multiline = true;
            this.txtRank.Name = "txtRank";
            this.txtRank.Size = new System.Drawing.Size(135, 28);
            this.txtRank.TabIndex = 35;
            // 
            // txtQlification
            // 
            this.txtQlification.Location = new System.Drawing.Point(128, 229);
            this.txtQlification.Multiline = true;
            this.txtQlification.Name = "txtQlification";
            this.txtQlification.Size = new System.Drawing.Size(135, 28);
            this.txtQlification.TabIndex = 34;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(656, 311);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(98, 44);
            this.btnClear.TabIndex = 40;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // Pilot
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::E_Space_Solution.Properties.Resources.Downpic_cc_2440572595;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.cbDob);
            this.Name = "Pilot";
            this.Size = new System.Drawing.Size(884, 713);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.cbDob.ResumeLayout(false);
            this.cbDob.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cbSpacehoures)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label DOD;
        private System.Windows.Forms.TextBox txtDeMiddlename;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtDeFirstname;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtDependentID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel cbDob;
        private System.Windows.Forms.TextBox txtRank;
        private System.Windows.Forms.TextBox txtQlification;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.NumericUpDown cbSpacehoures;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnClear;
    }
}
